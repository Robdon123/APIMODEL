# Edge Platform — automated odds monitor

## Phase 2

This build adds an unattended monitoring layer around the existing odds engine.

### Run locally

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# put provider keys in the environment / .env
uvicorn app:app --reload
```

Open `http://127.0.0.1:8000/`.

### Automated scanner

The scanner is **OFF by default**. Turn it on from the dashboard or set:

```text
AUTO_SCANNER=1
```

Important settings:

- `SCANNER_INTERVAL_SECONDS` — minimum 60 seconds
- `SCANNER_SPORTS` — comma-separated supported sport keys
- `SCANNER_MIN_EV`
- `SCANNER_MIN_BOOKS`
- `SCANNER_MAX_ODDS_AGE`

The scheduler stores every odds snapshot, scan run, qualifying opportunity and alert.

The scanner does **not** place real-money bets.

### UK bookmaker coverage

The Odds API request uses `regions=uk,eu`, so the scanner can compare every UK-facing bookmaker returned by the connected feed. This is **not a guarantee of every UK bookmaker in existence**. Coverage is provider-dependent and the dashboard reports the bookmaker feeds actually observed.

### API

Useful endpoints:

- `GET /scanner/status`
- `POST /scanner/config`
- `POST /scanner/scan`
- `GET /scanner/opportunities`
- `GET /scanner/alerts`

### Security

Do not put provider API keys into the GitHub Pages frontend for production. The backend should own provider credentials. Restrict `ALLOWED_ORIGINS` to your actual frontend origin before public deployment and add authentication/rate limiting before exposing the backend to the public internet.

### Research warning

The automated scanner finds market/model discrepancies. It does not establish a profitable betting edge. CLV, calibration and genuinely out-of-sample testing remain the evidence required to support such a claim.

## Phase 3 — research / forecasting engine

This build adds a separate research layer rather than silently treating market consensus as a predictive model.

### What is now implemented

- **Provider-independent event IDs** based on normalized teams + kickoff minute.
- **Settled-result store** for football outcomes.
- **API-Football result ingestion** by league/date via `POST /research/ingest-results`.
- **Dynamic Elo** with home advantage and explicit draw probability.
- **Regularized Poisson goal model with a fixed Dixon-Coles low-score correction** fitted to settled results.
- **Model-only ensemble calibration**: Elo/DC blend is selected on a chronological validation slice using Brier score; bookmaker prices are not used to choose the model weight.
- **Strict walk-forward backtesting**: each prediction is generated using only results before that match.
- **Model-vs-market evaluation**: historical odds are matched using normalized teams and kickoff time, so provider-specific event IDs do not have to match.
- **Research model registry** and prediction log for reproducibility.
- Dashboard **Research** tab for status, fitting and walk-forward backtests.

### Research endpoints

- `GET /research/status?sport=soccer_epl`
- `POST /research/ingest-results?sport=soccer_epl&date=YYYY-MM-DD&season=2025`
- `POST /research/fit?sport=soccer_epl`
- `POST /research/backtest?sport=soccer_epl&min_training=30&retrain_every=25`
- `GET /research/predict/{event_id}?sport=soccer_epl`
- `POST /research/outcomes?sport=soccer_epl` for importing a list of settled results directly

Example result payload for `/research/outcomes`:

```json
[
  {"kickoff":"2026-09-20T14:00:00Z","home":"Arsenal","away":"Chelsea","home_goals":2,"away_goals":1,"event_id":"optional-provider-id"}
]
```

### Building a meaningful historical dataset

For serious testing, ingest **months/seasons of settled results and timestamped odds snapshots** before interpreting model performance. A few dozen matches are enough to exercise the pipeline, not enough to establish predictive superiority. The scanner's live snapshots can accumulate forward-looking odds history; API-Football can supply settled results where the plan/key permits it.

The walk-forward report exposes Brier score, log loss and qualifying model EV observations. Those metrics should be read alongside CLV and sample size. No profitability claim is made by the software.
