"""Edge Platform – Phase 1 (data/odds infra + EV engine + football model + paper/CLV).
Run: uvicorn app:app --reload   |  Docs: http://localhost:8000/docs
No profitability is claimed: /paper/report says 'insufficient sample' until the data proves otherwise."""
import os, sqlite3, time, math, statistics, datetime, threading, uuid, json
from abc import ABC, abstractmethod
from collections import defaultdict
import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware

DB = os.getenv("DATABASE_URL", "sqlite:///edge.db").replace("sqlite:///", "")
SHARP = {"pinnacle", "betfair_ex_uk", "betfair_ex_eu", "matchbook", "smarkets"}
CFG = dict(min_ev=float(os.getenv("MIN_EV", .03)), strong_ev=.08, min_books=int(os.getenv("MIN_BOOKS", 4)),
           kelly=float(os.getenv("KELLY_FRACTION", .25)), stake_cap=float(os.getenv("STAKE_CAP", .03)))

def db():
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row; return c

with db() as c:
    c.executescript("""
    CREATE TABLE IF NOT EXISTS odds_snapshots(id INTEGER PRIMARY KEY, ts REAL, provider TEXT, sport TEXT,
      event_id TEXT, home TEXT, away TEXT, commence TEXT, bookmaker TEXT, market TEXT, selection TEXT, point REAL, price REAL);
    CREATE INDEX IF NOT EXISTS ix_ev ON odds_snapshots(event_id, market, ts);
    CREATE TABLE IF NOT EXISTS paper_bets(id INTEGER PRIMARY KEY, ts REAL, sport TEXT, event_id TEXT, event TEXT, market TEXT,
      selection TEXT, point REAL, bookmaker TEXT, odds REAL, fair_prob REAL, model_prob REAL, model_version TEXT,
      stake REAL, closing_fair_prob REAL, clv REAL, won INTEGER);
    CREATE TABLE IF NOT EXISTS scanner_config(
      id INTEGER PRIMARY KEY CHECK(id=1), enabled INTEGER NOT NULL DEFAULT 0,
      interval_seconds INTEGER NOT NULL DEFAULT 300, provider TEXT NOT NULL DEFAULT 'theoddsapi',
      sports TEXT NOT NULL DEFAULT 'soccer_epl', min_ev REAL NOT NULL DEFAULT 0.03,
      min_books INTEGER NOT NULL DEFAULT 4, max_odds_age_seconds INTEGER NOT NULL DEFAULT 180,
      last_scan REAL, next_scan REAL, updated_at REAL NOT NULL
    );
    CREATE TABLE IF NOT EXISTS scanner_runs(
      id INTEGER PRIMARY KEY, started_at REAL NOT NULL, finished_at REAL, provider TEXT, sport TEXT,
      rows INTEGER DEFAULT 0, opportunities INTEGER DEFAULT 0, error TEXT
    );
    CREATE TABLE IF NOT EXISTS scanner_opportunities(
      id INTEGER PRIMARY KEY, opportunity_key TEXT NOT NULL, detected_at REAL NOT NULL,
      run_id INTEGER, sport TEXT, event_id TEXT, event TEXT, market TEXT, selection TEXT, point REAL,
      bookmaker TEXT, odds REAL, fair_prob REAL, ev REAL, edge REAL, confidence REAL, books INTEGER,
      odds_age_seconds REAL, status TEXT NOT NULL DEFAULT 'DETECTED',
      closing_odds REAL, closing_fair_prob REAL, clv REAL
    );
    CREATE INDEX IF NOT EXISTS ix_scanner_opp_key ON scanner_opportunities(opportunity_key, detected_at);
    CREATE TABLE IF NOT EXISTS scanner_alerts(
      id INTEGER PRIMARY KEY, opportunity_key TEXT NOT NULL, created_at REAL NOT NULL,
      event TEXT, market TEXT, selection TEXT, bookmaker TEXT, odds REAL, ev REAL, message TEXT
    );
    CREATE TABLE IF NOT EXISTS immutable_events(
      id INTEGER PRIMARY KEY, entity_type TEXT NOT NULL, entity_id TEXT NOT NULL, action TEXT NOT NULL,
      ts REAL NOT NULL, payload TEXT NOT NULL
    );
    """)

# ---------- Provider abstraction (add Betfair/Sportradar/OpticOdds by subclassing) ----------
class OddsProvider(ABC):
    name = "base"
    @abstractmethod
    def fetch(self, sport: str, markets: str, **kw) -> list[dict]: ...

class TheOddsAPI(OddsProvider):
    """the-odds-api.com v4. Free tier ~500 credits/mo; bulk endpoint gives h2h/spreads/totals only;
    BTTS & player props need the per-event endpoint; historical odds is a paid tier; no UFC method markets."""
    name = "theoddsapi"
    def fetch(self, sport, markets="h2h,totals", **kw):
        r = httpx.get(f"https://api.the-odds-api.com/v4/sports/{sport}/odds/", timeout=30,
                      params=dict(apiKey=os.getenv("ODDS_API_KEY", ""), regions="uk,eu", markets=markets, oddsFormat="decimal"))
        r.raise_for_status()
        return [dict(event_id=e["id"], home=e["home_team"], away=e["away_team"], commence=e["commence_time"],
                     bookmaker=b["key"], market=m["key"], selection=o["name"], point=o.get("point"), price=o["price"])
                for e in r.json() for b in e["bookmakers"] for m in b["markets"] for o in m["outcomes"]]

class APIFootball(OddsProvider):
    """API-Football (api-sports.io). Header x-apisports-key; football only; free plan = 100 req/day and may restrict seasons.
    Maps 'Match Winner', 'Goals Over/Under', 'Both Teams Score' – verify field names in your dashboard Live Tester."""
    name = "apifootball"
    LEAGUES = {"soccer_epl": 39, "soccer_spain_la_liga": 140, "soccer_italy_serie_a": 135, "soccer_germany_bundesliga": 78,
               "soccer_france_ligue_one": 61, "soccer_uefa_champs_league": 2, "soccer_efl_champ": 40}
    def fetch(self, sport, markets="", date="", season=0, **kw):
        lg = self.LEAGUES.get(sport)
        if not lg: raise HTTPException(400, "API-Football covers football only")
        t = datetime.date.today(); date = date or t.isoformat(); season = season or (t.year if t.month >= 7 else t.year - 1)
        H = {"x-apisports-key": os.getenv("API_FOOTBALL_KEY", "")}
        def get(path, **q):
            d = httpx.get("https://v3.football.api-sports.io" + path, headers=H, params=q, timeout=30).json()
            if d.get("errors"): raise HTTPException(502, str(d["errors"]))
            return d
        fx = {x["fixture"]["id"]: x for x in get("/fixtures", league=lg, season=season, date=date)["response"]}
        rows, page, pages = [], 1, 1
        while page <= min(pages, 3):
            d = get("/odds", league=lg, season=season, date=date, page=page); pages = d.get("paging", {}).get("total", 1); page += 1
            for o in d["response"]:
                f = fx.get(o["fixture"]["id"])
                if not f: continue
                h, a = f["teams"]["home"]["name"], f["teams"]["away"]["name"]
                base = dict(event_id=str(o["fixture"]["id"]), home=h, away=a, commence=f["fixture"]["date"], point=None)
                for b in o["bookmakers"]:
                    bk = "".join(ch for ch in b["name"].lower() if ch.isalnum())
                    for bt in b["bets"]:
                        for v in bt["values"]:
                            px = float(v["odd"])
                            if bt["name"] == "Match Winner":
                                rows.append({**base, "bookmaker": bk, "market": "h2h", "selection": {"Home": h, "Away": a}.get(v["value"], "Draw"), "price": px})
                            elif bt["name"] == "Goals Over/Under":
                                side, pt = str(v["value"]).split(" ")
                                rows.append({**base, "bookmaker": bk, "market": "totals", "selection": side, "point": float(pt), "price": px})
                            elif bt["name"] == "Both Teams Score":
                                rows.append({**base, "bookmaker": bk, "market": "btts", "selection": v["value"], "price": px})
        return rows

PROVIDERS = {"theoddsapi": TheOddsAPI(), "apifootball": APIFootball()}

# ---------- Maths ----------
def devig(prices):
    """Power-method margin removal (handles favourite-longshot bias)."""
    p = [1 / x for x in prices]
    if sum(p) <= 1: return [x / sum(p) for x in p]
    lo, hi = 1.0, 30.0
    for _ in range(60):
        k = (lo + hi) / 2
        lo, hi = (k, hi) if sum(x ** k for x in p) > 1 else (lo, k)
    return [x ** ((lo + hi) / 2) for x in p]

def kelly(p, odds):
    full = max(0.0, (p * odds - 1) / (odds - 1))
    return dict(full=full, half=full / 2, quarter=full / 4, recommended=min(CFG["stake_cap"], full * CFG["kelly"]))

def consensus(rows):
    """{(event,market,point,selection): fair prob (sharp-weighted), dispersion, books, best soft price}."""
    g = defaultdict(lambda: defaultdict(dict)); meta = {}
    for r in rows:
        k = (r["event_id"], r["market"], r["point"]); g[k][r["bookmaker"]][r["selection"]] = r["price"]
        meta[r["event_id"]] = f'{r["home"]} v {r["away"]}'
    out = {}
    for (ev, mk, pt), books in g.items():
        n = max(len(b) for b in books.values())
        if n < 2: continue  # one-sided markets cannot be de-margined; skipped rather than assigned fair=1.0
        names = list(next(b for b in books.values() if len(b) == n))
        est = defaultdict(list); best = {}
        for bk, pr in books.items():
            if not all(s in pr for s in names): continue
            f = devig([pr[s] for s in names])
            for s, fp in zip(names, f): est[s] += [(fp, 3 if bk in SHARP else 1)]
            for s in names:
                if bk not in SHARP and pr[s] > best.get(s, (0, ""))[0]: best[s] = (pr[s], bk)
        for s, v in est.items():
            w = sum(x[1] for x in v); fair = sum(a * b for a, b in v) / w
            sd = statistics.pstdev([a for a, _ in v]) if len(v) > 1 else .1
            out[(ev, mk, pt, s)] = dict(event=meta[ev], fair=fair, sd=sd, n=len(v), best=best.get(s))
    return out

def latest_rows(sport, event_id=None):
    with db() as c:
        ts = c.execute("SELECT MAX(ts) FROM odds_snapshots WHERE sport=?", (sport,)).fetchone()[0]
        q = "SELECT * FROM odds_snapshots WHERE sport=? AND ts=?" + (" AND event_id=?" if event_id else "")
        return [dict(r) for r in c.execute(q, (sport, ts) + ((event_id,) if event_id else ()))] if ts else []

# ---------- Football: Dixon-Coles scoreline matrix ----------
def pois(l, k):
    p = math.exp(-l)
    for i in range(1, k + 1): p *= l / i
    return p

class FBIn(BaseModel):
    home_xg_for: float; home_xg_against: float; away_xg_for: float; away_xg_against: float
    league_avg: float = 1.4; home_adv: float = 1.12; rho: float = -0.08

def football(m: FBIn):
    lh = m.home_xg_for / m.league_avg * m.away_xg_against / m.league_avg * m.league_avg * m.home_adv
    la = m.away_xg_for / m.league_avg * m.home_xg_against / m.league_avg * m.league_avg / math.sqrt(m.home_adv)
    M = {}
    for i in range(11):
        for j in range(11):
            t = 1 - lh * la * m.rho if (i, j) == (0, 0) else 1 + lh * m.rho if (i, j) == (0, 1) else \
                1 + la * m.rho if (i, j) == (1, 0) else 1 - m.rho if (i, j) == (1, 1) else 1
            M[i, j] = pois(lh, i) * pois(la, j) * t
    z = sum(M.values()); M = {k: v / z for k, v in M.items()}
    s = lambda f: sum(v for (i, j), v in M.items() if f(i, j))
    return dict(lambda_home=lh, lambda_away=la, home=s(lambda i, j: i > j), draw=s(lambda i, j: i == j), away=s(lambda i, j: i < j),
                over={str(x + .5): s(lambda i, j, x=x: i + j > x) for x in (0, 1, 2, 3, 4)}, btts=s(lambda i, j: i and j),
                ah_home_minus_0_5=s(lambda i, j: i > j), ah_home_plus_0_5=s(lambda i, j: i >= j),
                top_scores=[dict(score=f"{i}-{j}", p=v) for (i, j), v in sorted(M.items(), key=lambda x: -x[1])[:6]])

# ---------- API ----------
app = FastAPI(title="Edge Platform – Automated Odds Monitor")

# Browser dashboard / GitHub Pages support. Restrict this in production with ALLOWED_ORIGINS.
_origins = [x.strip() for x in os.getenv("ALLOWED_ORIGINS", "*").split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=_origins, allow_credentials=False,
                   allow_methods=["*"], allow_headers=["*"])

SCANNER = {
    "enabled": False,
    "interval_seconds": int(os.getenv("SCANNER_INTERVAL_SECONDS", "300")),
    "provider": os.getenv("SCANNER_PROVIDER", "theoddsapi"),
    "sports": [x.strip() for x in os.getenv("SCANNER_SPORTS", "soccer_epl").split(",") if x.strip()],
    "min_ev": float(os.getenv("SCANNER_MIN_EV", "0.03")),
    "min_books": int(os.getenv("SCANNER_MIN_BOOKS", "4")),
    "max_odds_age_seconds": int(os.getenv("SCANNER_MAX_ODDS_AGE", "180")),
    "last_scan": None, "next_scan": None, "last_error": None,
}
_scanner_lock = threading.Lock()
_scanner_stop = threading.Event()

def _load_scanner_config():
    with db() as c:
        row = c.execute("SELECT * FROM scanner_config WHERE id=1").fetchone()
        if not row:
            c.execute("INSERT INTO scanner_config(id,enabled,interval_seconds,provider,sports,min_ev,min_books,max_odds_age_seconds,updated_at) VALUES(1,?,?,?,?,?,?,?,?)",
                      (int(os.getenv("AUTO_SCANNER","0").lower() in ("1","true","yes","on")), SCANNER["interval_seconds"], SCANNER["provider"], ",".join(SCANNER["sports"]), SCANNER["min_ev"], SCANNER["min_books"], SCANNER["max_odds_age_seconds"], time.time()))
            row = c.execute("SELECT * FROM scanner_config WHERE id=1").fetchone()
        for k in ("enabled","interval_seconds","provider","sports","min_ev","min_books","max_odds_age_seconds","last_scan","next_scan"):
            if k in row.keys(): SCANNER[k] = row[k]
        SCANNER["enabled"] = bool(SCANNER["enabled"])
        SCANNER["sports"] = [x.strip() for x in str(SCANNER["sports"]).split(",") if x.strip()]

_load_scanner_config()

def _persist_scanner():
    with db() as c:
        c.execute("UPDATE scanner_config SET enabled=?,interval_seconds=?,provider=?,sports=?,min_ev=?,min_books=?,max_odds_age_seconds=?,last_scan=?,next_scan=?,updated_at=? WHERE id=1",
                  (int(SCANNER["enabled"]), int(SCANNER["interval_seconds"]), SCANNER["provider"], ",".join(SCANNER["sports"]), float(SCANNER["min_ev"]), int(SCANNER["min_books"]), int(SCANNER["max_odds_age_seconds"]), SCANNER.get("last_scan"), SCANNER.get("next_scan"), time.time()))

def _bookmaker_coverage(rows):
    return sorted({r["bookmaker"] for r in rows})

def run_scanner_once(sport: str | None = None):
    """Fetch one snapshot, persist it, and persist qualifying opportunities. Never places bets."""
    provider = SCANNER["provider"]; sport = sport or SCANNER["sports"][0]
    started = time.time(); run_id = None
    with db() as c:
        cur = c.execute("INSERT INTO scanner_runs(started_at,provider,sport) VALUES(?,?,?)", (started, provider, sport)); run_id = cur.lastrowid
    try:
        if provider not in PROVIDERS: raise RuntimeError(f"Unknown provider: {provider}")
        if provider == "theoddsapi" and not os.getenv("ODDS_API_KEY"): raise RuntimeError("ODDS_API_KEY is not configured")
        if provider == "apifootball" and not os.getenv("API_FOOTBALL_KEY"): raise RuntimeError("API_FOOTBALL_KEY is not configured")
        kwargs = {}
        if provider == "apifootball":
            now = datetime.datetime.now(datetime.timezone.utc)
            kwargs.update(date=now.date().isoformat(), season=now.year if now.month >= 7 else now.year-1)
        rows = PROVIDERS[provider].fetch(sport, "h2h,totals", **kwargs)
        ts = time.time()
        with db() as c:
            c.executemany("INSERT INTO odds_snapshots(ts,provider,sport,event_id,home,away,commence,bookmaker,market,selection,point,price) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
              [(ts,provider,sport,r["event_id"],r["home"],r["away"],r["commence"],r["bookmaker"],r["market"],r["selection"],r.get("point"),r["price"]) for r in rows])
        candidates=[]
        for (ev,mk,pt,sel), cns in consensus(rows).items():
            if not cns["best"] or cns["n"] < int(SCANNER["min_books"]): continue
            odds,bk=cns["best"]
            evv=cns["fair"]*odds-1
            if evv < float(SCANNER["min_ev"]): continue
            confidence=100*min(1,cns["n"]/8)*max(0,1-cns["sd"]/.04)
            # The snapshot is fresh at detection; this is later recomputed from stored timestamps.
            candidates.append(dict(event_id=ev,event=cns["event"],market=mk,selection=sel,point=pt,bookmaker=bk,odds=odds,
                                   fair_prob=cns["fair"],ev=evv,edge=cns["fair"]-1/odds,confidence=confidence,books=cns["n"],odds_age_seconds=0))
        with db() as c:
            for x in candidates:
                key="|".join(map(str,[sport,x["event_id"],x["market"],x["point"],x["selection"]]))
                c.execute("INSERT INTO scanner_opportunities(opportunity_key,detected_at,run_id,sport,event_id,event,market,selection,point,bookmaker,odds,fair_prob,ev,edge,confidence,books,odds_age_seconds,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                          (key,ts,run_id,sport,x["event_id"],x["event"],x["market"],x["selection"],x["point"],x["bookmaker"],x["odds"],x["fair_prob"],x["ev"],x["edge"],x["confidence"],x["books"],0,"DETECTED"))
                # Alert only when a new opportunity appears or EV/price changes materially.
                prev=c.execute("SELECT odds,ev FROM scanner_opportunities WHERE opportunity_key=? AND id != last_insert_rowid() ORDER BY id DESC LIMIT 1",(key,)).fetchone()
                should_alert = prev is None or abs(float(prev[0])-x["odds"]) >= .02 or abs(float(prev[1])-x["ev"]) >= .01
                if should_alert:
                    msg=f'{x["event"]} | {x["market"]} | {x["selection"]} | {x["bookmaker"]} @ {x["odds"]:.2f} | EV {x["ev"]*100:.1f}% | confidence {x["confidence"]:.0f}'
                    c.execute("INSERT INTO scanner_alerts(opportunity_key,created_at,event,market,selection,bookmaker,odds,ev,message) VALUES(?,?,?,?,?,?,?,?,?)",
                              (key,ts,x["event"],x["market"],x["selection"],x["bookmaker"],x["odds"],x["ev"],msg))
            c.execute("UPDATE scanner_runs SET finished_at=?,rows=?,opportunities=? WHERE id=?",(time.time(),len(rows),len(candidates),run_id))
        SCANNER["last_scan"]=ts; SCANNER["next_scan"]=ts+int(SCANNER["interval_seconds"]); SCANNER["last_error"]=None; _persist_scanner()
        return dict(run_id=run_id, rows=len(rows), opportunities=len(candidates), bookmakers=_bookmaker_coverage(rows), timestamp=ts)
    except Exception as e:
        with db() as c: c.execute("UPDATE scanner_runs SET finished_at=?,error=? WHERE id=?",(time.time(),str(e),run_id))
        SCANNER["last_error"]=str(e); SCANNER["next_scan"]=time.time()+int(SCANNER["interval_seconds"]); _persist_scanner()
        raise

def _scanner_worker():
    while not _scanner_stop.is_set():
        if SCANNER.get("enabled") and time.time() >= (SCANNER.get("next_scan") or 0):
            with _scanner_lock:
                for sport in list(SCANNER["sports"]):
                    if not SCANNER.get("enabled"): break
                    try: run_scanner_once(sport)
                    except Exception: pass
        _scanner_stop.wait(1)

threading.Thread(target=_scanner_worker, name="edge-scanner", daemon=True).start()

@app.get("/scanner/status")
def scanner_status():
    with db() as c:
        providers=c.execute("SELECT bookmaker,COUNT(*) n FROM odds_snapshots GROUP BY bookmaker ORDER BY n DESC").fetchall()
        runs=c.execute("SELECT * FROM scanner_runs ORDER BY id DESC LIMIT 10").fetchall()
        alerts=c.execute("SELECT * FROM scanner_alerts ORDER BY id DESC LIMIT 20").fetchall()
        opps=c.execute("SELECT * FROM scanner_opportunities ORDER BY id DESC LIMIT 100").fetchall()
    return {"enabled":SCANNER["enabled"],"interval_seconds":SCANNER["interval_seconds"],"provider":SCANNER["provider"],"sports":SCANNER["sports"],"min_ev":SCANNER["min_ev"],"min_books":SCANNER["min_books"],"max_odds_age_seconds":SCANNER["max_odds_age_seconds"],"last_scan":SCANNER.get("last_scan"),"next_scan":SCANNER.get("next_scan"),"last_error":SCANNER.get("last_error"),"bookmakers":[dict(x) for x in providers],"runs":[dict(x) for x in runs],"alerts":[dict(x) for x in alerts],"opportunities":[dict(x) for x in opps]}

class ScannerConfig(BaseModel):
    enabled: bool | None = None
    interval_seconds: int | None = None
    provider: str | None = None
    sports: list[str] | None = None
    min_ev: float | None = None
    min_books: int | None = None
    max_odds_age_seconds: int | None = None

@app.post("/scanner/config")
def scanner_config(cfg: ScannerConfig):
    if cfg.interval_seconds is not None:
        if cfg.interval_seconds < 60: raise HTTPException(400,"Minimum scanner interval is 60 seconds")
        SCANNER["interval_seconds"]=cfg.interval_seconds
    if cfg.provider is not None:
        if cfg.provider not in PROVIDERS: raise HTTPException(400,"Unsupported provider")
        SCANNER["provider"]=cfg.provider
    if cfg.sports is not None:
        if not cfg.sports: raise HTTPException(400,"At least one sport is required")
        SCANNER["sports"]=cfg.sports
    if cfg.min_ev is not None: SCANNER["min_ev"]=max(0,float(cfg.min_ev))
    if cfg.min_books is not None: SCANNER["min_books"]=max(2,int(cfg.min_books))
    if cfg.max_odds_age_seconds is not None: SCANNER["max_odds_age_seconds"]=max(15,int(cfg.max_odds_age_seconds))
    if cfg.enabled is not None:
        SCANNER["enabled"]=bool(cfg.enabled)
        if SCANNER["enabled"]: SCANNER["next_scan"]=0
        else: SCANNER["next_scan"]=None
    _persist_scanner()
    return scanner_status()

@app.post("/scanner/scan")
def scanner_scan(sport: str | None = None):
    with _scanner_lock:
        return run_scanner_once(sport)

@app.get("/scanner/opportunities")
def scanner_opportunities(limit: int = 100, min_ev: float | None = None):
    limit=max(1,min(500,int(limit)))
    with db() as c:
        q="SELECT * FROM scanner_opportunities WHERE status='DETECTED'"; args=[]
        if min_ev is not None: q += " AND ev>=?"; args.append(min_ev)
        q += " ORDER BY ev DESC, confidence DESC LIMIT ?"; args.append(limit)
        return [dict(x) for x in c.execute(q,args)]

@app.get("/scanner/alerts")
def scanner_alerts(limit: int = 50):
    with db() as c: return [dict(x) for x in c.execute("SELECT * FROM scanner_alerts ORDER BY id DESC LIMIT ?",(max(1,min(500,int(limit))),))]


@app.post("/ingest/{sport}")
def ingest(sport: str, provider: str = "theoddsapi", markets: str = "h2h,totals", date: str = "", season: int = 0):
    need = "API_FOOTBALL_KEY" if provider == "apifootball" else "ODDS_API_KEY"
    if not os.getenv(need): raise HTTPException(400, f"Set {need} in environment")
    rows, ts = PROVIDERS[provider].fetch(sport, markets, date=date, season=season), time.time()
    with db() as c:
        c.executemany("INSERT INTO odds_snapshots(ts,provider,sport,event_id,home,away,commence,bookmaker,market,selection,point,price)"
                      " VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                      [(ts, provider, sport, r["event_id"], r["home"], r["away"], r["commence"], r["bookmaker"], r["market"],
                        r["selection"], r["point"], r["price"]) for r in rows])
    return dict(snapshot_ts=ts, rows=len(rows))

@app.get("/opportunities/{sport}")
def opportunities(sport: str, min_ev: float = CFG["min_ev"], min_books: int = CFG["min_books"]):
    """Market-consensus fair price vs best soft-book price. NOT a proven edge until CLV data says so."""
    res = []
    for (ev, mk, pt, sel), c in consensus(latest_rows(sport)).items():
        if not c["best"] or c["n"] < min_books: continue
        odds, bk = c["best"]; e = c["fair"] * odds - 1
        if e < min_ev: continue
        conf = round(100 * min(1, c["n"] / 8) * max(0, 1 - c["sd"] / .04))
        tier = ("Strong EV" if e >= CFG["strong_ev"] else "Qualifying EV") if conf >= 60 else "High-uncertainty EV"
        res.append(dict(event_id=ev, event=c["event"], market=mk, point=pt, selection=sel, best_odds=odds, bookmaker=bk,
                        fair_prob=round(c["fair"], 4), fair_odds=round(1 / c["fair"], 3), edge=round(c["fair"] - 1 / odds, 4),
                        ev=round(e, 4), confidence=conf, books=c["n"], tier=tier, kelly=kelly(c["fair"], odds)))
    return sorted(res, key=lambda r: (-r["confidence"] * r["ev"])) or "NO QUALIFYING BET"

@app.get("/movement/{event_id}")
def movement(event_id: str, market: str = "h2h"):
    """Observed price history per bookmaker/selection (no interpretation as 'sharp money')."""
    with db() as c:
        return [dict(r) for r in c.execute("SELECT ts,bookmaker,selection,point,price FROM odds_snapshots "
                                           "WHERE event_id=? AND market=? ORDER BY ts", (event_id, market))]

@app.post("/model/football")
def model_football(m: FBIn): return football(m)

class Paper(BaseModel):
    sport: str; event_id: str; market: str; selection: str; point: float | None = None
    bookmaker: str; odds: float; fair_prob: float; model_prob: float | None = None
    model_version: str = "market-consensus-v0"; stake: float = 0

@app.post("/paper")
def paper(b: Paper):
    with db() as c:
        ev = c.execute("SELECT home||' v '||away FROM odds_snapshots WHERE event_id=? LIMIT 1", (b.event_id,)).fetchone()
        now=time.time()
        cur = c.execute("INSERT INTO paper_bets(ts,sport,event_id,event,market,selection,point,bookmaker,odds,fair_prob,model_prob,model_version,stake)"
                        " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)", (now, b.sport, b.event_id, ev[0] if ev else "", b.market,
                        b.selection, b.point, b.bookmaker, b.odds, b.fair_prob, b.model_prob, b.model_version, b.stake))
        c.execute("INSERT INTO immutable_events(entity_type,entity_id,action,ts,payload) VALUES(?,?,?,?,?)",
                  ("paper_bet",str(cur.lastrowid),"PREDICTION",now,json.dumps({"sport":b.sport,"event_id":b.event_id,"market":b.market,"selection":b.selection,"odds":b.odds,"fair_prob":b.fair_prob,"model_prob":b.model_prob,"model_version":b.model_version,"stake":b.stake})))
    return dict(id=cur.lastrowid)

@app.post("/paper/{bet_id}/close")
def close(bet_id: int):
    """Call just before kick-off after a fresh /ingest: stores the closing consensus fair prob and CLV."""
    with db() as c:
        b = c.execute("SELECT * FROM paper_bets WHERE id=?", (bet_id,)).fetchone()
        if not b: raise HTTPException(404)
        row = c.execute("SELECT commence FROM odds_snapshots WHERE event_id=? ORDER BY ts DESC LIMIT 1", (b["event_id"],)).fetchone()
        if row and row["commence"]:
            try:
                kickoff=datetime.datetime.fromisoformat(str(row["commence"]).replace("Z","+00:00")).timestamp()
                if time.time() >= kickoff: raise HTTPException(409, "Kick-off has passed; this cannot be recorded as a closing snapshot")
            except ValueError: pass
        cons = consensus(latest_rows(b["sport"], b["event_id"])).get((b["event_id"], b["market"], b["point"], b["selection"]))
        if not cons: raise HTTPException(409, "No closing snapshot – ingest first")
        clv = b["odds"] * cons["fair"] - 1
        # Prediction rows remain immutable. Store the closing observation as an append-only event.
        c.execute("INSERT INTO immutable_events(entity_type,entity_id,action,ts,payload) VALUES(?,?,?,?,?)",
                  ("paper_bet",str(bet_id),"CLOSE",time.time(),json.dumps({"closing_fair_prob":cons["fair"],"clv":clv})))
    return dict(closing_fair_prob=cons["fair"], clv=clv)

@app.post("/paper/{bet_id}/result")
def result(bet_id: int, won: bool):
    with db() as c:
        if not c.execute("SELECT 1 FROM paper_bets WHERE id=?", (bet_id,)).fetchone(): raise HTTPException(404)
        c.execute("INSERT INTO immutable_events(entity_type,entity_id,action,ts,payload) VALUES(?,?,?,?,?)",
                  ("paper_bet",str(bet_id),"RESULT",time.time(),json.dumps({"won":bool(won)})))
    return "ok"

@app.get("/paper/report")
def report():
    with db() as c:
        bets=[dict(r) for r in c.execute("SELECT * FROM paper_bets")]
        events=[dict(r) for r in c.execute("SELECT entity_id,action,payload,ts FROM immutable_events WHERE entity_type='paper_bet' ORDER BY ts")]
    state={}
    for e in events:
        sid=int(e["entity_id"]); payload=json.loads(e["payload"]); state.setdefault(sid,{})
        if e["action"]=="CLOSE": state[sid].update(payload)
        elif e["action"]=="RESULT": state[sid]["won"]=payload.get("won")
    for b in bets: b.update(state.get(b["id"],{}))
    clv=[b["clv"] for b in bets if b.get("clv") is not None]
    st=[b for b in bets if b.get("won") is not None and b["stake"]]
    prof=sum(b["stake"]*(b["odds"]-1) if b["won"] else -b["stake"] for b in st)
    mp=[(b["model_prob"],b["won"]) for b in bets if b["model_prob"] is not None and b.get("won") is not None]
    n=len(clv); se=statistics.stdev(clv)/math.sqrt(n) if n>2 else None
    verdict="INSUFFICIENT SAMPLE – no edge can be claimed (need several hundred bets with CLV)." if n<300 else ("Positive CLV, statistically significant (>2 s.e.)." if se and statistics.mean(clv)>2*se else "No statistically significant CLV edge.")
    return dict(bets=len(bets),with_clv=n,avg_clv=statistics.mean(clv) if clv else None,clv_std_err=se,
                roi=prof/sum(b["stake"] for b in st) if st else None,
                brier=statistics.mean((p-w)**2 for p,w in mp) if mp else None,verdict=verdict)

# ---------- UFC/MMA: method + round model (anchor win prob to the devigged market; don't guess it) ----------
class MMAIn(BaseModel):
    p_a: float                      # P(A wins), e.g. devigged consensus moneyline adjusted by your view
    a_ko: float; a_sub: float       # A's share of wins by KO/TKO and by submission (rest = decision)
    b_ko: float; b_sub: float
    rounds: int = 3
    finish_round_weights: list[float] | None = None   # P(finish occurs in round r | finish); default is generic, replace with fitted values

@app.post("/model/mma")
def model_mma(m: MMAIn):
    w = m.finish_round_weights or ({3: [.42, .33, .25], 5: [.33, .25, .20, .13, .09]}[m.rounds])
    w = [x / sum(w) for x in w]
    pb = 1 - m.p_a
    a = dict(ko=m.p_a * m.a_ko, sub=m.p_a * m.a_sub, dec=m.p_a * max(0, 1 - m.a_ko - m.a_sub))
    b = dict(ko=pb * m.b_ko, sub=pb * m.b_sub, dec=pb * max(0, 1 - m.b_ko - m.b_sub))
    dist = a["dec"] + b["dec"]; fin = 1 - dist
    over = {f"{r + .5}": dist + fin * sum(w[r + 1:]) for r in range(m.rounds - 1)}
    return dict(a_wins=m.p_a, b_wins=pb, a=a, b=b, goes_distance=dist, ends_inside=fin, over_rounds=over,
                under_rounds={k: 1 - v for k, v in over.items()}, ko_tko=a["ko"] + b["ko"], submission=a["sub"] + b["sub"],
                note="Method splits should blend each fighter's finish rate with the opponent's rate of being finished; validate against results before trusting.")

# ---------- Dashboard ----------
from fastapi.responses import FileResponse
@app.get("/", include_in_schema=False)
def home(): return FileResponse(os.path.join(os.path.dirname(__file__), "dashboard.html"))

# ---------- Phase 3: research/forecasting engine ----------
import re, hashlib

with db() as c:
    c.executescript("""
    CREATE TABLE IF NOT EXISTS football_outcomes(
      id INTEGER PRIMARY KEY, canonical_event_id TEXT UNIQUE NOT NULL, sport TEXT NOT NULL,
      event_id TEXT, kickoff REAL NOT NULL, home TEXT NOT NULL, away TEXT NOT NULL,
      home_team_id TEXT NOT NULL, away_team_id TEXT NOT NULL, home_goals INTEGER NOT NULL,
      away_goals INTEGER NOT NULL, source TEXT, ingested_at REAL NOT NULL
    );
    CREATE INDEX IF NOT EXISTS ix_outcomes_kickoff ON football_outcomes(kickoff);
    CREATE TABLE IF NOT EXISTS research_models(
      id INTEGER PRIMARY KEY, fitted_at REAL NOT NULL, sport TEXT NOT NULL, model_version TEXT NOT NULL,
      train_start REAL, train_end REAL, observations INTEGER NOT NULL, brier REAL, logloss REAL,
      elo_weight REAL, dc_weight REAL, params_json TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS research_predictions(
      id INTEGER PRIMARY KEY, created_at REAL NOT NULL, canonical_event_id TEXT NOT NULL,
      kickoff REAL NOT NULL, home TEXT NOT NULL, away TEXT NOT NULL, model_version TEXT NOT NULL,
      p_home REAL NOT NULL, p_draw REAL NOT NULL, p_away REAL NOT NULL,
      market_home REAL, market_draw REAL, market_away REAL, best_home REAL, best_draw REAL, best_away REAL,
      outcome INTEGER, brier REAL, logloss REAL
    );
    CREATE INDEX IF NOT EXISTS ix_predictions_event ON research_predictions(canonical_event_id);
    """)

TEAM_RE = re.compile(r"[^a-z0-9]+")
def canonical_team_id(name: str) -> str:
    return TEAM_RE.sub("", str(name).lower())

def parse_ts(value):
    if isinstance(value, (int,float)): return float(value)
    s=str(value).replace("Z", "+00:00")
    try: return datetime.datetime.fromisoformat(s).timestamp()
    except Exception: return 0.0

def canonical_event_id(home, away, kickoff):
    # Provider-independent key: normalized teams + kickoff minute. Event IDs differ across feeds.
    raw=f"{canonical_team_id(home)}|{canonical_team_id(away)}|{int(kickoff//60)}"
    return hashlib.sha1(raw.encode()).hexdigest()[:24]

def _outcome_rows(sport="soccer_epl"):
    with db() as c: return [dict(r) for r in c.execute("SELECT * FROM football_outcomes WHERE sport=? ORDER BY kickoff",(sport,))]

def ingest_outcomes(rows, sport="soccer_epl", source="manual"):
    n=0
    with db() as c:
        for r in rows:
            ko=parse_ts(r.get("kickoff") or r.get("commence"))
            if not ko: continue
            h,a=str(r["home"]),str(r["away"]); hg=int(r["home_goals"]); ag=int(r["away_goals"])
            cid=canonical_event_id(h,a,ko)
            c.execute("INSERT OR REPLACE INTO football_outcomes(canonical_event_id,sport,event_id,kickoff,home,away,home_team_id,away_team_id,home_goals,away_goals,source,ingested_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                      (cid,sport,str(r.get("event_id",cid)),ko,h,a,canonical_team_id(h),canonical_team_id(a),hg,ag,source,time.time())); n+=1
    return n

@app.post("/research/outcomes")
def research_outcomes(rows: list[dict], sport: str="soccer_epl"):
    """Ingest settled football results. Payload: [{kickoff,home,away,home_goals,away_goals,event_id?}]."""
    return {"inserted":ingest_outcomes(rows,sport,"manual")}

@app.post("/research/ingest-results")
def research_ingest_results(sport: str="soccer_epl", date: str="", season: int=0):
    if not os.getenv("API_FOOTBALL_KEY"): raise HTTPException(400,"Set API_FOOTBALL_KEY in environment")
    p=PROVIDERS.get("apifootball")
    if not isinstance(p, APIFootball): raise HTTPException(400,"API-Football provider unavailable")
    lg=p.LEAGUES.get(sport)
    if not lg: raise HTTPException(400,"Unsupported football league")
    d=date or datetime.date.today().isoformat(); season=season or (datetime.date.fromisoformat(d).year if datetime.date.fromisoformat(d).month>=7 else datetime.date.fromisoformat(d).year-1)
    H={"x-apisports-key":os.getenv("API_FOOTBALL_KEY","")}
    r=httpx.get("https://v3.football.api-sports.io/fixtures",headers=H,params={"league":lg,"season":season,"date":d},timeout=30); r.raise_for_status(); payload=r.json()
    if payload.get("errors"): raise HTTPException(502,str(payload["errors"]))
    rows=[]
    for x in payload.get("response",[]):
        g=x.get("goals",{}); h=x.get("teams",{}).get("home",{}); a=x.get("teams",{}).get("away",{})
        if g.get("home") is None or g.get("away") is None: continue
        rows.append(dict(event_id=x["fixture"]["id"],kickoff=x["fixture"]["date"],home=h.get("name"),away=a.get("name"),home_goals=g["home"],away_goals=g["away"]))
    return {"date":d,"season":season,"inserted":ingest_outcomes(rows,sport,"api-football")}

class ResearchFitIn(BaseModel):
    sport: str="soccer_epl"
    min_observations: int=30
    validation_fraction: float=.2

class EloState:
    def __init__(self, k=20.0, home_adv=55.0, base=1500.0): self.k=k; self.home_adv=home_adv; self.base=base; self.r={}
    def rating(self,t): return self.r.get(t,self.base)
    def probs(self,h,a):
        d=self.rating(h)+self.home_adv-self.rating(a); ph=1/(1+10**(-d/400));
        # Empirical draw component: highest near equal ratings; keeps a true 3-way distribution.
        draw=.28*math.exp(-abs(d)/180)
        draw=min(draw, ph*.9, (1-ph)*.9)
        return ((1-draw)*ph, draw, (1-draw)*(1-ph))
    def update(self,h,a,result):
        ph,pd,pa=self.probs(h,a); target=1 if result==0 else .5 if result==1 else 0
        expected=ph+.5*pd; delta=self.k*(target-expected); self.r[h]=self.rating(h)+delta; self.r[a]=self.rating(a)-delta

def _elo_train(rows, k=20.0):
    s=EloState(k=k)
    for r in rows:
        result=0 if r["home_goals"]>r["away_goals"] else 1 if r["home_goals"]==r["away_goals"] else 2
        s.update(r["home_team_id"],r["away_team_id"],result)
    return s

def _fit_dc(rows, steps=900, lr=.008, reg=.015):
    teams=sorted({x["home_team_id"] for x in rows}|{r["away_team_id"] for r in rows}); idx={t:i for i,t in enumerate(teams)}; n=len(teams)
    atk=[0.0]*n; de=[0.0]*n; ha=math.log(1.12); base=math.log(max(.2, sum(r["home_goals"]+r["away_goals"] for r in rows)/(2*len(rows))))
    # Regularized Poisson log-likelihood; gradient descent on log-rate parameters.
    for _ in range(steps):
        ga=[0.0]*n; gd=[0.0]*n; gha=0.0; gb=0.0
        for r in rows:
            i,j=idx[r["home_team_id"]],idx[r["away_team_id"]]
            lh=math.exp(base+ha+atk[i]-de[j]); la=math.exp(base+atk[j]-de[i])
            gh=r["home_goals"]-lh; ga[i]+=gh; gd[j]-=gh
            ga[j]+=r["away_goals"]-la; gd[i]-=(r["away_goals"]-la)
            gha+=gh
        for i in range(n): ga[i]-=reg*atk[i]; gd[i]-=reg*de[i]
        for i in range(n): atk[i]+=lr*ga[i]/max(1,len(rows)); de[i]+=lr*gd[i]/max(1,len(rows))
        ha+=lr*gha/max(1,len(rows)); base+=lr*gb/max(1,len(rows))
    return {"atk":dict(zip(teams,atk)),"def":dict(zip(teams,de)),"home_adv":ha,"base":base}

def _dc_probs(params,h,a):
    atk=params["atk"]; de=params["def"]; base=params["base"]; ha=params["home_adv"]
    lh=math.exp(base+ha+atk.get(h,0)-de.get(a,0)); la=math.exp(base+atk.get(a,0)-de.get(h,0))
    M={}
    rho=-0.08
    for i in range(9):
        for j in range(9):
            tau=1.0
            if (i,j)==(0,0): tau=1-lh*la*rho
            elif (i,j)==(0,1): tau=1+lh*rho
            elif (i,j)==(1,0): tau=1+la*rho
            elif (i,j)==(1,1): tau=1-rho
            M[i,j]=pois(lh,i)*pois(la,j)*tau
    z=sum(M.values()); M={k:v/z for k,v in M.items()}
    return (sum(v for (i,j),v in M.items() if i>j),sum(v for (i,j),v in M.items() if i==j),sum(v for (i,j),v in M.items() if i<j))

def _brier(probs,result): return sum((p-(1 if i==result else 0))**2 for i,p in enumerate(probs))/3

def _logloss(probs,result): return -math.log(max(1e-9,probs[result]))

def _fit_ensemble(rows, validation_fraction=.2):
    if len(rows)<2: raise HTTPException(400,"Not enough outcomes")
    cut=max(1,int(len(rows)*(1-validation_fraction))); train=rows[:cut]; val=rows[cut:] or rows[-1:]
    elo=_elo_train(train); dc=_fit_dc(train)
    # Model-only calibration: choose the weight minimizing validation Brier. No market odds are used.
    best=(1e9,.5); candidates=[i/20 for i in range(21)]
    for w in candidates:
        loss=0
        for r in val:
            pe=elo.probs(r["home_team_id"],r["away_team_id"]); pd=_dc_probs(dc,r["home_team_id"],r["away_team_id"])
            p=tuple(w*a+(1-w)*b for a,b in zip(pe,pd)); result=0 if r["home_goals"]>r["away_goals"] else 1 if r["home_goals"]==r["away_goals"] else 2; loss+=_brier(p,result)
        if loss<best[0]: best=(loss,w)
    w=best[1]
    return elo,dc,w,cut

def _snapshot_market(event, kickoff):
    # Match provider-specific odds to provider-independent outcomes by normalized teams + kickoff window.
    with db() as c:
        candidates=[dict(r) for r in c.execute("SELECT * FROM odds_snapshots WHERE ts<=? ORDER BY ts DESC",(kickoff,))]
    target=None
    with db() as c:
        target=c.execute("SELECT home,away FROM football_outcomes WHERE event_id=? LIMIT 1",(str(event),)).fetchone()
    if target:
        th,ta=canonical_team_id(target[0]),canonical_team_id(target[1])
        candidates=[r for r in candidates if canonical_team_id(r["home"])==th and canonical_team_id(r["away"])==ta and abs(parse_ts(r["commence"])-kickoff)<=7200]
    if not candidates: return None
    latest_ts=max(r["ts"] for r in candidates); rows=[r for r in candidates if r["ts"]==latest_ts]
    cns=consensus(rows); out={}
    for (ev,mk,pt,sel),x in cns.items():
        if mk!="h2h": continue
        if x.get("best") and x["fair"]: out[sel]=dict(fair=x["fair"],best=x["best"][0],book=x["best"][1])
    return out

@app.post("/research/fit")
def research_fit(m: ResearchFitIn):
    rows=_outcome_rows(m.sport)
    if len(rows)<m.min_observations: raise HTTPException(400,f"Need at least {m.min_observations} settled outcomes; have {len(rows)}")
    elo,dc,w,cut=_fit_ensemble(rows,m.validation_fraction)
    train=rows[:cut]; val=rows[cut:]
    br=[]; ll=[]
    for r in val:
        pe=elo.probs(r["home_team_id"],r["away_team_id"]); pd=_dc_probs(dc,r["home_team_id"],r["away_team_id"]); p=tuple(w*a+(1-w)*b for a,b in zip(pe,pd)); y=0 if r["home_goals"]>r["away_goals"] else 1 if r["home_goals"]==r["away_goals"] else 2; br.append(_brier(p,y)); ll.append(_logloss(p,y))
    params={"elo_k":elo.k,"elo_home_adv":elo.home_adv,"elo_ratings":elo.r,"dc":dc,"ensemble_elo_weight":w,"ensemble_dc_weight":1-w}
    version=f"ensemble-elo-dc-v1-{int(time.time())}"
    with db() as c: c.execute("INSERT INTO research_models(fitted_at,sport,model_version,train_start,train_end,observations,brier,logloss,elo_weight,dc_weight,params_json) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(time.time(),m.sport,version,train[0]["kickoff"],train[-1]["kickoff"],len(train),statistics.mean(br) if br else None,statistics.mean(ll) if ll else None,w,1-w,json.dumps(params)))
    return {"model_version":version,"observations":len(train),"validation_observations":len(val),"brier":statistics.mean(br) if br else None,"logloss":statistics.mean(ll) if ll else None,"elo_weight":w,"dc_weight":1-w}

@app.get("/research/status")
def research_status(sport: str="soccer_epl"):
    with db() as c:
        n=c.execute("SELECT COUNT(*) FROM football_outcomes WHERE sport=?",(sport,)).fetchone()[0]
        latest=c.execute("SELECT * FROM research_models WHERE sport=? ORDER BY id DESC LIMIT 1",(sport,)).fetchone()
    return {"sport":sport,"outcomes":n,"latest_model":dict(latest) if latest else None,"note":"Model quality is empirical: use walk-forward results and CLV, not a single in-sample fit."}

@app.post("/research/backtest")
def research_backtest(sport: str="soccer_epl", min_training: int=30, retrain_every: int=25):
    rows=_outcome_rows(sport)
    if len(rows)<min_training+1: raise HTTPException(400,f"Need >{min_training} outcomes; have {len(rows)}")
    predictions=[]; br=[]; ll=[]; value=[]; bets=0
    # Strict walk-forward: each prediction only sees outcomes strictly before kickoff.
    for i in range(min_training,len(rows)):
        train=rows[:i]
        if (i-min_training)%max(1,retrain_every)==0 or not predictions:
            elo,dc,w,_=_fit_ensemble(train,.2)
        r=rows[i]; pe=elo.probs(r["home_team_id"],r["away_team_id"]); pd=_dc_probs(dc,r["home_team_id"],r["away_team_id"]); p=tuple(w*a+(1-w)*b for a,b in zip(pe,pd)); y=0 if r["home_goals"]>r["away_goals"] else 1 if r["home_goals"]==r["away_goals"] else 2
        br.append(_brier(p,y)); ll.append(_logloss(p,y)); market=_snapshot_market(r["event_id"],r["kickoff"])
        best=market or {}; best_home=best.get(r["home"],{}).get("best"); best_draw=best.get("Draw",{}).get("best"); best_away=best.get(r["away"],{}).get("best")
        if best_home and p[0]*best_home-1>=CFG["min_ev"]: value.append(p[0]*best_home-1); bets+=1
        if best_draw and p[1]*best_draw-1>=CFG["min_ev"]: value.append(p[1]*best_draw-1); bets+=1
        if best_away and p[2]*best_away-1>=CFG["min_ev"]: value.append(p[2]*best_away-1); bets+=1
        predictions.append((r,p,market))
    with db() as c:
        for r,p,market in predictions:
            y=0 if r["home_goals"]>r["away_goals"] else 1 if r["home_goals"]==r["away_goals"] else 2
            c.execute("INSERT INTO research_predictions(created_at,canonical_event_id,kickoff,home,away,model_version,p_home,p_draw,p_away,market_home,market_draw,market_away,best_home,best_draw,best_away,outcome,brier,logloss) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (time.time(),canonical_event_id(r["home"],r["away"],r["kickoff"]),r["kickoff"],r["home"],r["away"],"walk-forward-elo-dc-v1",*p,
                       (market or {}).get(r["home"],{}).get("fair"),(market or {}).get("Draw",{}).get("fair"),(market or {}).get(r["away"],{}).get("fair"),
                       (market or {}).get(r["home"],{}).get("best"),(market or {}).get("Draw",{}).get("best"),(market or {}).get(r["away"],{}).get("best"),y,_brier(p,y),_logloss(p,y)))
    return {"predictions":len(predictions),"brier":statistics.mean(br) if br else None,"logloss":statistics.mean(ll) if ll else None,"qualifying_model_ev_observations":bets,"mean_qualifying_ev":statistics.mean(value) if value else None,"note":"This is a walk-forward research result. It is not a profitability guarantee; execution, limits, line movement and selection availability are not simulated."}

@app.get("/research/predict/{event_id}")
def research_predict(event_id: str, sport: str="soccer_epl"):
    rows=_outcome_rows(sport)
    with db() as c: latest=c.execute("SELECT * FROM research_models WHERE sport=? ORDER BY id DESC LIMIT 1",(sport,)).fetchone()
    if not latest: raise HTTPException(404,"Fit a research model first")
    params=json.loads(latest["params_json"]); elo=EloState(k=params.get("elo_k",20)); elo.r=params["elo_ratings"]; dc=params["dc"]; w=params["ensemble_elo_weight"]
    with db() as c: snap=c.execute("SELECT * FROM odds_snapshots WHERE event_id=? ORDER BY ts DESC LIMIT 1",(event_id,)).fetchone()
    if not snap: raise HTTPException(404,"Event odds not found")
    h,a=snap["home"],snap["away"]; pe=elo.probs(canonical_team_id(h),canonical_team_id(a)); pd=_dc_probs(dc,canonical_team_id(h),canonical_team_id(a)); p=tuple(w*x+(1-w)*y for x,y in zip(pe,pd))
    return {"event_id":event_id,"home":h,"away":a,"model_version":latest["model_version"],"p_home":p[0],"p_draw":p[1],"p_away":p[2],"fair_odds":{"home":1/p[0],"draw":1/p[1],"away":1/p[2]},"note":"Probabilities are model estimates; compare with current verified prices and later CLV before treating as an edge."}
