// Saves raw Big Ball Sports match data to disk with a fetch timestamp (for later model fitting / research).
// Uses ONLY the call from the SDK's own example: client.matches.list({ sport, league, limit }) -> { data }.
// Field names in the response are unverified, so the raw JSON is stored untouched.
// Usage:  BBS_API_KEY=your_key node fetch_matches.mjs [sport] [league] [limit]
import { BigBallSportsClient } from '@bigballsdata/sdk';
import { mkdirSync, writeFileSync } from 'node:fs';

const key = process.env.BBS_API_KEY;
if (!key) { console.error('Set BBS_API_KEY in your environment (never paste it into code or chat).'); process.exit(1); }
const [sport = 'mma', league = 'ufc', limit = '50'] = process.argv.slice(2);

const client = new BigBallSportsClient(key);
try {
  const { data } = await client.matches.list({ sport, league, limit: Number(limit) });
  mkdirSync('data', { recursive: true });
  const file = `data/${sport}_${league}_${new Date().toISOString().replace(/[:.]/g, '-')}.json`;
  writeFileSync(file, JSON.stringify({ fetched_at: new Date().toISOString(), sport, league, data }, null, 2));
  console.log(`Saved ${Array.isArray(data) ? data.length : '?'} records to ${file}`);
} catch (e) {
  console.error('Big Ball Sports request failed:', e?.status ?? '', e?.message ?? e);
  process.exit(2);
}
